package RegistrationLogin;

import static RegistrationLogin.UserInfo.setTaskNumber;
import javax.swing.JOptionPane;

public class Task 
{
    UserInfo taskinput = new UserInfo();
    
    public boolean checkTaskDescription(){
        if(taskinput.getTaskDescription().length()<=50)
        {
            return true;
        }
        else 
        {
            return false;
        }
    }
   
    public static String createTaskID(){
        String count = " ";
        char charecter;
        for(int x = 0; x < UserInfo.getDeveloperNames().length(); x++){
            charecter = UserInfo.getDeveloperNames().charAt(x);
            if(charecter == ' '){
            count = UserInfo.getDeveloperNames().substring(x-3, x);
        }
        }
        String iD = UserInfo.getTaskName().substring(0, 2)+":"+ UserInfo.getTaskNumber()+":"+count;
                
        return iD.toUpperCase();
      
    }
    
    public static String printTaskDetails(){
        return "Task Status: "+UserInfo.getTaskStatus()+"\n"+"Developer Names: "+UserInfo.getDeveloperNames()+"\n"+"Task Number: "+UserInfo.getTaskNumber()+"\n"+
               "Task Name: "+ UserInfo.getTaskName()+"\n"+"Task Description: "+UserInfo.getTaskDescription()+"\n"+"Task ID: "+ createTaskID()+"\n"+"Task Duration: "+UserInfo.getTaskDuration();
    }
    
   public int returnTotalHours(){
       return UserInfo.Duration;
    }
}
