
package RegistrationLogin;

import javax.swing.JOptionPane;
// declaring our string data types
public class Registration {
    
     static String FirstName;
     static String Username;
     static String LastName;
     static String Password;
 // put the scanner we have imported to use and also declaring userDetails method   
    public static void userDetails(){
        
        FirstName =  JOptionPane.showInputDialog("Please enter you first name");
        
        LastName = JOptionPane.showInputDialog("Please enter your surname");
                
        Username = JOptionPane.showInputDialog("Please enter your userName");
       
        Password = JOptionPane.showInputDialog("Please enter your password");
       
        
    }
    public static void main(String[] args) {
       userDetails();
        Login logObject = new Login();
        
        logObject.checkUserName();
        logObject.registerUser();
        UserInfo info = new UserInfo();
        info.WelcomeNote();
    }
    
 // combining our class login with userDetails and bring all our method to communicate with one another to get the result we were asked to prepare.
   
}
