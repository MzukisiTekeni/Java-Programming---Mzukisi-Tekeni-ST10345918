
package RegistrationLogin;

import java.util.Scanner;
import javax.swing.JOptionPane;


class UserInfo 
{
    private static int NumberOfTask;
    private static String TaskName;
    public static int TaskNumber;
    private static String TaskDescription;
    private static String DeveloperNames;
    private static int TaskDuration;
    private static int TaskID;
    private static String TaskStatus;
    static int Duration = 0;
  
    Scanner Input = new Scanner(System.in);
    public static void setNumberOfTask()
    {
        NumberOfTask = Integer.parseInt(JOptionPane.showInputDialog("Please enter the number os tasks you want to perform: "));
    }
    public static int getNumberOfTask(){
        return NumberOfTask;
    }
    public static void setTaskName(){
        
        TaskName = JOptionPane.showInputDialog("Please enter the task Name: ");
        
    }
    public static String getTaskName(){
        return TaskName;
    }
    
    public static void setTaskNumber(int x){
          TaskNumber = x;
    }
    public static int getTaskNumber(){
        return TaskNumber;
    }
    
    public static void setDiscription(){
        
        TaskDescription = JOptionPane.showInputDialog("Please enter Task Discription: ");
        
    }
    public static String getTaskDescription()
    {
        return TaskDescription;
    }
    public static void setDeveloperNames()
    {
        
        DeveloperNames = JOptionPane.showInputDialog("Please enter Developer Names: ");
        
    }
    public static String getDeveloperNames()
    {
        return DeveloperNames;
    }
    
    public static void setDuration()
    {
        TaskDuration = Integer.parseInt(JOptionPane.showInputDialog("Please enter Task Duration: ")); 
    }
    public static int getTaskDuration()
    {
        return TaskDuration;
    }
    
     public static void setStatus(){
         //creating Choice and organising the task that needs to be done
        
        TaskStatus = JOptionPane.showInputDialog("Choose task status \n"
                + "To DO\n"
                + "Doing\n"
                + "Done");
        
    }
    public static String getTaskStatus(){
        return TaskStatus;
    }
    
    public static void WelcomeNote()
    {
          int Choice;
          int end = 0;
          Login logObj = new Login();
          Task Taskobj = new Task();
      
          if(logObj.loginUser())
          {
              do{
              
               Choice = Integer.parseInt(JOptionPane.showInputDialog("Welcome to EasyKanban\n"
                  + "Please select an option \n"
                  + "1. Add task \n"
                  + "2. Show report \n"
                  + "3. Quit "));
         
              
            if(Choice == 1)
            {
                
                setNumberOfTask();
                
                for(int count= 0; count<getNumberOfTask(); count++)
                {
                    
                    setStatus();
                    setTaskNumber(count);
                    setTaskName();
                    setDiscription();
                    setDuration();
                    setDeveloperNames();
                    
                    Duration = Duration+ getTaskDuration();
                    JOptionPane.showMessageDialog(null, Taskobj.printTaskDetails());
                }
                JOptionPane.showMessageDialog(null, "These tasks will take " + Duration + " to implement");
                
                continue;
            }
            else if(Choice == 2)
            {
            JOptionPane.showMessageDialog(null,"Coming soon");
            continue;
            }
            else if(Choice == 3)
            {

               end= 3; 
            }
          
             }
              while(end != 3);
          }
    }
}
    
