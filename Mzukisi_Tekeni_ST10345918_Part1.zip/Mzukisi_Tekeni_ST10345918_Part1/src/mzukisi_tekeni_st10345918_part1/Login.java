
package mzukisi_tekeni_st10345918_part1;
import java.util.Scanner;

public class Login 
{
    static Scanner Input = new Scanner(System.in);
    static Account NewAccount;
    static boolean LoginDetailsOkay = false;
    public static void main(String[] args) 
    {
        
                System.out.println();
                String Username;
                String Password;
                String Firstname;
                String Lastname;
                System.out.println("=============== ACCOUNT REGISTRATION==================");
                System.out.print("Please create a new Username: ");
                Username = Input.nextLine();
        
                System.out.print("Please create a new Password: ");
                Password = Input.nextLine();
        
                System.out.print("Please Enter your First Name: ");
                Firstname = Input.nextLine();
        
                System.out.print("Please Enter your Last Name: ");
                Lastname = Input.nextLine();
        
                System.out.println();
                System.out.println();
        
                System.out.println(registerUser(Username,Password,Firstname,Lastname));
                System.out.println("=====================================================");
                System.out.println();
                
            if(LoginDetailsOkay == true)
            {
                System.out.print("PLEASE PRESS ENTER TO GO TO THE LOGIN SECTION");
                Input.nextLine();
            
                System.out.println();
                System.out.print("=================LOGIN TO YOUR ACCOUNT===============");
                System.out.println();
                System.out.print("Please Enter your Username: ");
                Username = Input.nextLine();
                System.out.print("Please Enter Your Password: ");
                 Password = Input.nextLine();
                Firstname = NewAccount.getFirstname();
                 Lastname = NewAccount.getLastname();
                System.out.println();
                System.out.println();
                System.out.println(returnLoginStatus(Username,Password,Firstname,Lastname));
                System.out.println("=====================================================");
            }
    }
  public static boolean checkUserName(String Username)
  {
        return Username.contains("_")&& Username.length()<=5;
        
  }
    
public static boolean checkPasswordComplexity(String Password)
 {
         boolean hasDigit = false;
         boolean hasEightCharacters = false;
         boolean hasSpecialCharacters = false;
         boolean hasCapital = false;
         char[] MyChars = Password.toCharArray();
        
        if(Password.length() >= 8)
        {
            hasEightCharacters = true;
        }
        for (int i = 0; i < MyChars.length; i++) 
        {
            if(Character.isDigit(MyChars[i]))
            {
                hasDigit = true;
            }
            if(Character.isUpperCase(MyChars[i]))
            {
                hasCapital = true;
            }
            if(!Character.isDigit(MyChars[i])&& !Character.isWhitespace(MyChars[i])
                    && !Character.isLetter(MyChars[i]))
            {
                hasSpecialCharacters = true;
            }
           
        }
      
       return hasDigit == true && hasCapital == true && hasSpecialCharacters == true 
               && hasEightCharacters == true;
            
 }
        
     public static String registerUser(String Username, String Password, String Firstname, String Lastname)
     {
        if(checkUserName(Username)== true && checkPasswordComplexity(Password) == true )
        {
            NewAccount = new Account(Username, Password,Firstname,Lastname);
            LoginDetailsOkay = true;
            return """
                   Username Successfully captured 
                   Password successfully captured""";
        }
        else if(checkUserName(Username) == false && checkPasswordComplexity(Password)== false)
        {
             return """
                   Username and Password are not correctly formatted, please ensure your username contains an underscore and is no more than 5 characters in length.
                    Please ensure that the password contains at least 8 characters, a capital letter, a number and a special character""";
        
        }
        else if(checkUserName(Username)== false)
        {
            return "Username is not correctly formatted,"+ 
                   "please ensure your username contains an underscore and is no more than 5 characters in length.";
        }
        else  
        {
            return "Your Password is not correctly formatted, "
                    + "please ensure that the passowrd contains at least 8 characters, a capital letter, a number,"
                    + "and a special character";
        }
    }
     
     public static boolean LoginUser(String Username, String Password)
     {
         return NewAccount.getUsername().equals(Username) && NewAccount.getPasword().equals(Password);
     }
     
     public static String returnLoginStatus(String Username, String Password, String Firstname, String Lastname)
     {
         if(LoginUser(Username,Password) == true)
         {
             return "Welcome "+Firstname+" , "+Lastname+" it is great to see you again";
         }
         else
         {
             return "Username or Password incorrect, please try again";
         }
     }
}
    

