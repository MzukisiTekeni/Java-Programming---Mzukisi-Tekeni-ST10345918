
package mzukisi_tekeni_st10345918_part1;


public class Account 
{
    private String Username;
    private String Firstname;
    private String Lastname;
    private String Password;
   
    public Account(String Username,String Password, String Firstname, String Lastname)
    {
      this.Username = Username;  
      this.Password = Password;
      this.Firstname = Firstname;
      this.Lastname = Lastname;
    }
    public void setUsername(String Username)
    {
        this.Username = Username;
    }
    public String getUsername()
    {
        return this.Username;
    }
    public void setPassword(String Password)
    {
        this.Password = Password;
    }
    public String getPasword()
    {
        return this.Password;
    }
    public void setFirstname(String Firstname)
    {
        this.Firstname = Firstname;
    }
    public String getFirstname()
    {
        return this.Firstname;
    }
    public void setLastname(String Lastname)
    {
        this.Lastname= Lastname;
    }
    public String getLastname()
    {
        return this.Lastname;
    }   
}
