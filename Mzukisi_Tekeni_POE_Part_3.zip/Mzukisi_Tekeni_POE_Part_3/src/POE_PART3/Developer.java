
package POE_PART3;


public class Developer
{
    private String FirstName;
    private String LastName;
    
    public Developer(String FirstName, String LastName)
    {
        this.FirstName = FirstName;
        this.LastName = LastName;
    }
    public void SetFirstName(String FirstName)
    {
        this.FirstName = FirstName;
    }
    public void SetLastName(String LastName)
    {
        this.LastName = LastName;
    }
    public String GetFirstName()
    {
        return this.FirstName;
    }
    public String GetLastName()
    {
        return this.LastName;
    }
}
